"use strict";

sap.ui.define(["sap/fe/core/AppComponent"], function (BaseComponent) {
  "use strict";

  /**
   * @namespace zitatech.itassetreqsub.itassetreqsub
   */
  var Component = BaseComponent.extend("zitatech.itassetreqsub.itassetreqsub.Component", {
    metadata: {
      manifest: "json"
    }
  });
  return Component;
});
//# sourceMappingURL=Component-dbg.js.map
